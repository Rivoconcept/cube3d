This is a simple project using raycasting, it was developed by me during my studies at 42SP.

The test can be done with the following commands:
```sh
git clone https://github.com/roneyrogerio/cub3D.git
cd cub3D && make
./cub3D c3d.cub
```

![test](https://raw.githubusercontent.com/roneyrogerio/cub3D/master/print.gif)
