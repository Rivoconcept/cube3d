# cub3d
Реализация проекта cub3D в стиле The last of us.
Написано на C (Си) с использованием библиотеки miniLibX.
Видео тут: https://youtu.be/PHa8XLQAX8A
